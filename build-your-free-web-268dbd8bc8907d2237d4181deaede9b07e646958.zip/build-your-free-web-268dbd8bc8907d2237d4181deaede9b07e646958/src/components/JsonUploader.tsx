import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { Upload, Download, X, FileText, Share2, Copy } from 'lucide-react';

interface FileData {
  name: string;
  size: number;
  parsedData: any;
  rawText: string;
}

const JsonUploader = () => {
  const [fileData, setFileData] = useState<FileData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.name.endsWith('.json') && file.type !== 'application/json') {
      toast({
        title: "Invalid file type",
        description: "Please select a .json file",
        variant: "destructive"
      });
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select a file smaller than 5MB",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      
      const newFileData = {
        name: file.name,
        size: file.size,
        parsedData: parsed,
        rawText: text
      };

      setFileData(newFileData);
      localStorage.setItem('lastUploadedJson', JSON.stringify(newFileData));
      
      toast({
        title: "JSON uploaded successfully",
        description: `Parsed ${file.name} (${(file.size / 1024).toFixed(1)} KB)`
      });
    } catch (error) {
      toast({
        title: "JSON parse error",
        description: error instanceof Error ? error.message : "Invalid JSON format",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setFileData(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    localStorage.removeItem('lastUploadedJson');
    toast({
      title: "Cleared",
      description: "JSON data has been cleared"
    });
  };

  const handleDownload = () => {
    if (!fileData) return;

    const blob = new Blob([JSON.stringify(fileData.parsedData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileData.name.replace('.json', '')}-processed.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleShare = async () => {
    if (!fileData) return;

    try {
      const encodedData = encodeURIComponent(JSON.stringify({
        name: fileData.name,
        data: fileData.parsedData
      }));
      
      const shareUrl = `${window.location.origin}${window.location.pathname}?shared=${encodedData}`;
      
      if (navigator.share) {
        await navigator.share({
          title: `Shared JSON: ${fileData.name}`,
          text: `Check out this JSON data: ${fileData.name}`,
          url: shareUrl
        });
      } else {
        await navigator.clipboard.writeText(shareUrl);
        toast({
          title: "Share link copied!",
          description: "The share link has been copied to your clipboard"
        });
      }
    } catch (error) {
      toast({
        title: "Share failed",
        description: "Could not create share link",
        variant: "destructive"
      });
    }
  };

  // Load from localStorage or URL on mount
  React.useEffect(() => {
    // Check for shared data in URL first
    const urlParams = new URLSearchParams(window.location.search);
    const sharedData = urlParams.get('shared');
    
    if (sharedData) {
      try {
        const decoded = JSON.parse(decodeURIComponent(sharedData));
        const sharedFileData = {
          name: decoded.name,
          size: JSON.stringify(decoded.data).length,
          parsedData: decoded.data,
          rawText: JSON.stringify(decoded.data, null, 2)
        };
        setFileData(sharedFileData);
        toast({
          title: "Shared JSON loaded",
          description: `Loaded shared file: ${decoded.name}`
        });
        return;
      } catch (error) {
        toast({
          title: "Invalid share link",
          description: "Could not load shared JSON data",
          variant: "destructive"
        });
      }
    }

    // Otherwise load from localStorage
    const saved = localStorage.getItem('lastUploadedJson');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setFileData(parsed);
      } catch {
        localStorage.removeItem('lastUploadedJson');
      }
    }
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            JSON File Uploader
          </CardTitle>
          <CardDescription>
            Upload and parse JSON files (up to 5MB). Data is processed locally in your browser.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleFileSelect}
              disabled={isLoading}
              className="flex-1"
            />
            <Button
              variant="outline"
              onClick={handleClear}
              disabled={!fileData}
              size="sm"
            >
              <X className="h-4 w-4 mr-2" />
              Clear
            </Button>
            <Button
              variant="outline"
              onClick={handleDownload}
              disabled={!fileData}
              size="sm"
            >
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
            <Button
              variant="outline"
              onClick={handleShare}
              disabled={!fileData}
              size="sm"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
          </div>

          {isLoading && (
            <div className="text-center py-4">
              <div className="text-sm text-muted-foreground">Processing file...</div>
            </div>
          )}

          {fileData && !isLoading && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <div className="font-medium">{fileData.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {(fileData.size / 1024).toFixed(1)} KB
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">
                  {Array.isArray(fileData.parsedData) 
                    ? `${fileData.parsedData.length} items`
                    : typeof fileData.parsedData === 'object'
                    ? `${Object.keys(fileData.parsedData).length} properties`
                    : typeof fileData.parsedData
                  }
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium">JSON Preview</div>
                <ScrollArea className="h-96 w-full rounded-md border p-4">
                  <pre className="text-xs">
                    {JSON.stringify(fileData.parsedData, null, 2)}
                  </pre>
                </ScrollArea>
              </div>
            </div>
          )}

          {!fileData && !isLoading && (
            <div className="text-center py-8 text-muted-foreground">
              <Upload className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <div>Select a JSON file to get started</div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default JsonUploader;