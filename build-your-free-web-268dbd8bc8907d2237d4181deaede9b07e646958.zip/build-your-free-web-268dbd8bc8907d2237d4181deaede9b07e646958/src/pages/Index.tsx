import JsonUploader from '@/components/JsonUploader';

const Index = () => {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">The All Play Project</h1>
          <p className="text-xl text-muted-foreground">Upload and process your JSON files</p>
        </div>
        <JsonUploader />
      </div>
    </div>
  );
};

export default Index;
